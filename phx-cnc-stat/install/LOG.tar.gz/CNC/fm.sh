#!/bin/sh
/CNC/fm -l /cps -r /cps
if [ -b /dev/fd0 ]; then 
	umount /fs/fd
	sleep 5
	slay -9 devb-fdc
fi
