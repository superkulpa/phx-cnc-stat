#! /bin/sh
#set -x
chkfsys -urqP /
rm -Rf /tmp/* /CNC/tmp/*
#find /CNC/logs  -name 'log*' -atime +7 -exec rm {}
