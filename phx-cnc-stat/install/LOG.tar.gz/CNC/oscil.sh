#! /bin/sh
/CNC/phxOscil -f
exit