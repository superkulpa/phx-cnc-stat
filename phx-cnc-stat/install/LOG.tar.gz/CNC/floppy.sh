#!/bin/sh
#set -x

#kill -9 `pidin ar | awk '{ print $1 "\t" $2 }' | grep check_floppy.sh  | awk '{ print $1 }' `
#slay -9 check_floppy.sh
#kill -9 `pidin ar | awk '{ print $1 "\t" $2 }' | grep devb-fdc  | awk '{ print $1 }' `
slay -9 devb-fdc

devb-fdc &
waitfor /dev/fd0 60

#rm -fR /fs/fd/*
mount -tdos /dev/fd0 /fs/fd

mkdir /cps/floppy 2>/dev/null
cp -fR /fs/fd/*   /cps/floppy
sleep 5
umount /fs/fd
sleep 2
slay -9 devb-fdc
