#time 
#-Xdbg:transport=dt_socket,address=8888,server=y,suspend=n
/usr/java/j9/bin/j9 -cp /usr/java/libs/JavaKernel.jar:/usr/java/libs/commons-logging-1.0.4.jar:/usr/java/libs/log4j-1.2.11.jar:/usr/java/libs/jdom.jar:/usr/java/libs/xml.jar:/usr/java/libs/commons-collections-3.2.1.jar:/usr/java/libs/commons-net-1.4.1.jar ru.autogenmash.core.utils.compiler.Compiler $1 $2 $3 $4 $5
#:/usr/java/libs/xml.jar
#:/usr/java/libs/crimson.jar
