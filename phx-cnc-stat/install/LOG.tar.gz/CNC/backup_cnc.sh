#!/bin/sh

echo "backup /CNC"

rm -Rf /CNC/logs/log*

BACKUP_DIR=/home/cust/backup_`date "+D%d_%m_%Y_T%H_%M"`

echo $BACKUP_DIR > /home/cust/lastbackup
mkdir $BACKUP_DIR
#cp -fR /CNC $BACKUP_DIR
tar -czf $BACKUP_DIR/cnc.tar.gz /CNC

echo "backup complete "
