#! /bin/sh
/CNC/io2
