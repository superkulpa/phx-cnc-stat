#!/bin/sh
cd /CNC
/CNC/statForm
/CNC/backup_log.xml.sh

