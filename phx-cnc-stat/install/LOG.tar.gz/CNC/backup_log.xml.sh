#! /bin/sh
#set -x

unset TARGET
TARGET=/home/ftp/pub/updates
mkdir -m777 $TARGET  	2>/dev/null

tar -czf $TARGET/logs.xml.tar.gz  /CNC/stat/stat.ini  /CNC/logs/*/*.xml 2>/CNC/logs/backup_log.xml.last
lastError=$?
if [ ! $lastError -eq 0 ]; then
#if ! test -z $lastError; then
	echo "Operation fault: "$lastError
	exit $lastError
fi
cp -ft $TARGET/logs.xml.tar.gz /cps/flash*

echo "Operation complete"
