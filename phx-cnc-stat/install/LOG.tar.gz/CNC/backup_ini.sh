#!/bin/sh
#set -x

unset TARGET
TARGET=/home/ftp/pub/updates
mkdir -m777 $TARGET  	2>/dev/null

tar -czf ${TARGET}/ini_CNC.tar.gz /CNC/*.ini

# 
LIST=`ls -1d /cps/flash* 2>/dev/null`
for i in $LIST
	do
	if [ -w $i ]; then
		cp -tf ${TARGET}/ini_CNC.tar.gz $i
		exit 0
	fi
done


chmod 666 /CNC/archive/*.ini
cp -f /CNC/*.ini /CNC/archive
chmod 444 /CNC/archive/*.ini
cp -f /CNC/*.ini /CNC/backup
