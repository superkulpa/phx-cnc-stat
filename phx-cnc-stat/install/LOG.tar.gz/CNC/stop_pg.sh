#!/bin/sh

/usr/local/pgsql/bin/pg_ctl stop -D /CNC/dbs/data
