#! /bin/sh
#set -x
WITH_WAIT=${1}

TARGET_DIR=/home/ftp/pub/updates
mkdir -p -m777 $TARGET_DIR 2>/dev/null

echo Copy updates from flash, please wait ...

LIST=`ls -1d /cps/flash* 2>/dev/null`
for i in $LIST
	do		
		cp -f ${i}/CNC*.tar.gz ${TARGET_DIR}
		cp -f ${i}/CNC*.tar.gz.asc ${TARGET_DIR}
done

echo Check and install updates ...

rm -f /CNC/tmp/corrupted_updates.list

LIST=`ls -1p ${TARGET_DIR}/CNC*.tar.gz 2>/dev/null`
for i in $LIST
	do
	gzip -t $i > /dev/null
	if [ ! $? -eq 0 ];	then
			echo $i >> /CNC/tmp/corrupted_updates.list
			rm -f $i $i.asc
			
			echo WARNING: %i corrupted, install skipped
			continue
	fi
	done

if [ -f /CNC/tmp/corrupted_updates.list ]
	then
		echo install completed
	fi
	
if [ " "$WITH_WAIT == " wait" ]
	then	
		read rboot?"for reboot press ENTER key"
	fi
	
exit 0
