#!/bin/sh

/usr/local/pgsql/bin/postmaster -D /CNC/dbs/data
