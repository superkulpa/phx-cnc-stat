#!/bin/sh
#set -x

#kill devb-umass
#kill -9 `pidin ar | awk '{ print $1 "\t" $2 }' | grep devb-umass  | awk '{ print $1 }' `

#kill io-usb
#kill -9 `pidin ar | awk '{ print $1 "\t" $2 }' | grep io-usb  | awk '{ print $1 }' `

#io-usb -d uhci
#waitfor /dev/io-usb 10
#sleep 5
#devb-umass  
#waitfor /dev/hd1		10

#if [ -r /dev/hd1t11 ]; then
#	umount /cps/flash1
#	mount -tdos /dev/hd1t11 /cps/flash1
#fi
#
#if [ -r /dev/hd1t6 ]; then
#	umount /cps/flash2
#	mount -tdos /dev/hd1t6 /cps/flash2
#fi



