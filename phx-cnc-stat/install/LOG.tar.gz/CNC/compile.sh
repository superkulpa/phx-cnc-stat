#!/bin/sh
#echo $1 > /compile.out
#echo $2 >> /compile.out
#echo $3 >> /compile.out
#echo $4 >> /compile.out
#echo $5 >> /compile.out
FTP_TMP=/home/ftp/pub/tmp
/CNC/cpc $1 $2 $3 $4 $5 200 > /dev/null
