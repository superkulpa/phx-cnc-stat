#!/bin/sh
#set -x
unset SOURCE
SOURCE=/home/ftp/pub/updates

cd ${SOURCE}
tar -xzf ${SOURCE}/ini_CNC.tar.gz
cp ${SOURCE}/CNC/*.ini ${SOURCE}
rm -R ${SOURCE}/CNC
