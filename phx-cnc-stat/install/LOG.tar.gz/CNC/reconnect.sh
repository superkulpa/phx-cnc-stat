slay -f devc-ser8250
devc-ser8250 -b9600 3f8,4 -b19200 2f8,3
waitfor /dev/ser1 5
waitfor /dev/ser2 5