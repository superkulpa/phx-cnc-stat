#! /bin/sh
cd /CNC
./reconnect.sh
#export JAVA_HOME=/usr/java/j9
/usr/java/j9/bin/j9  -cp "/usr/java/libs/cuttingconsoles.jar:/usr/java/libs/xml.jar:/usr/java/libs/commons-collections-3.2.1.jar:/usr/java/libs/pg72jdbc2.jar:/usr/java/libs/commons-net-1.4.1.jar:/usr/java/libs/swt.jar:/usr/java/libs/draw2d.jar:/usr/java/libs/core.commands.jar:/usr/java/libs/core.runtime.jar:/usr/java/libs/equinox.common.jar:/usr/java/libs/jface.jar:/usr/java/libs/jface.text.jar:/usr/java/libs/osgi.jar:/usr/java/libs/text.jar:/usr/java/libs/JavaKernel.jar:/usr/java/libs/form.jar:/usr/java/libs/commons-logging-1.0.4.jar:/usr/java/libs/log4j-1.2.11.jar" -Djava.library.path=/usr/java/libs ru.autogenmash.cuttingconsoles.PlasmaConsoleStarter >/dev/ser2 2>/CNC/logs/plasma.last </dev/ser2
