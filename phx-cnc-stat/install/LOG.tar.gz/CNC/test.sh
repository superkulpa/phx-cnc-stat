﻿#!/bin/sh
#set -x
echo "Hello world"
echo "Привет мир"
