#! /bin/sh
pterm -h90% -n