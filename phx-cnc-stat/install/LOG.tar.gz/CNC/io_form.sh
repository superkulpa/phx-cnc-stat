#!/bin/sh
/CNC/ioConsole -rk1
exit
