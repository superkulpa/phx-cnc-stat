#!/bin/sh

sleep 8
while true
do
	./form
	if [ $? -eq 0 ]
		then
		echo "exit from CNC software"
		slay phxStarter
		kill 0
		exit
	fi

	sleep 1
done

