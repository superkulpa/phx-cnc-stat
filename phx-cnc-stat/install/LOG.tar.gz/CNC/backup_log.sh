#! /bin/sh
#set -x

LOG_DIR=${1}
CUR_CP=${2}

CUR_CP=`fullpath $CUR_CP`

unset TARGET
TARGET=/home/ftp/pub/updates
mkdir -m777 $TARGET  	2>/dev/null

if [ -z $EXCLUDES ]; then
	EXCLUDES="--exclude=*.so --exclude=phx* --exclude=/CNC/form --exclude=/CNC/kernel --exclude=/CNC/statForm --exclude=/CNC/phcmd --exclude=/CNC/logo --exclude=/CNC/cpc --exclude=/CNC/dbs --exclude-tag=nobackup"
fi
#echo $EXCLUDES

tar -czf $TARGET/LOG.tar.gz  $EXCLUDES /CNC /etc/* /usr/startup /usr/ph ${CUR_CP}

cp -ft $TARGET/LOG.tar.gz /cps/flash*
