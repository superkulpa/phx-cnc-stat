#!/bin/sh
#set -x

export PATH=/CNC:$PATH
export LD_LIBRARY_PATH=/CNC:$LD_LIBRARY_PATH

KERNEL_START=kernel

while true
do
  sleep 4
	echo "write logs to "$LOG_DIR
	echo "start form"
	/CNC/form.sh > $LOG_DIR/form.out.txt &
	FORM_PID=$!
	echo "start kernel"
	echo Log start at `date "+%d_%m_%Y__%H_%M_%S"`> $LOG_DIR/kernel.out.txt
	echo `kernel -v` 															>> $LOG_DIR/kernel.out.txt
	echo User Id: `id` 														>> $LOG_DIR/kernel.out.txt

	if [ $KERNEL_START == "kernel" ]
		then
		/CNC/kernel >> $LOG_DIR/kernel.out.txt
	else
		echo "License expired"
		echo "License expired" >> $LOG_DIR/kernel.out.txt
		while true
		do
			/CNC/logo
			sleep 2
		done
		sleep 6000
	fi

  slay form
	kill $FORM_PID
	exit 0
done


