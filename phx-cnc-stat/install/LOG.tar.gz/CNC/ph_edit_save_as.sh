#! /bin/sh
#set -x
sh /CNC/backup_log.sh

