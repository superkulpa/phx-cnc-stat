#!/bin/sh
slay -9 devb-fdc
devb-fdc &
waitfor /dev/fd0 60
mount -tdos /dev/fd0 /fs/fd
